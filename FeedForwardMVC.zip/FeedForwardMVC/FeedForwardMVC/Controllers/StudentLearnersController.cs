﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using FeedForwardMVC.Models;

namespace FeedForwardMVC.Controllers
{
    public class StudentLearnersController : Controller
    {
        private FeedForward1Entities db = new FeedForward1Entities();

        // GET: StudentLearners
        //public ActionResult Index()
        //{
        //    return View(db.StudentLearners.ToList());
        //}
        //------------------------------------------------------------
        public ActionResult Index(string searchString)
        {
            //DbSet<StudentLearner> Query = db.StudentLearners;
            //var Query1 = db.StudentLearners;
            //if (!String.IsNullOrEmpty(searchString))
            //{
            //    Query1 = (DbSet<StudentLearner>)db.StudentLearners.Where(s => s.Gender.Contains(searchString) || s.CurrentYear.Contains(searchString));
            //}

            return View(db.StudentLearners.Where(s => s.Gender.Contains(searchString) || s.CurrentYear.Contains(searchString) || searchString == null).ToList());
            //return View(db.StudentLearners.ToList());
            //return View(Query1.ToList());
        }
        //------------------------------------------------------------


        // GET: StudentLearners/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            StudentLearner studentLearner = db.StudentLearners.Find(id);
            if (studentLearner == null)
            {
                return HttpNotFound();
            }
            return View(studentLearner);
        }

        // GET: StudentLearners/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: StudentLearners/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "StudentID,FirstName,LastName,Gender,CurrentYear,Street,City,State,Zip,Email,Phone,Country,ProgramID,TrackID")] StudentLearner studentLearner)
        {
            if (ModelState.IsValid)
            {
                db.StudentLearners.Add(studentLearner);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(studentLearner);
        }

        // GET: StudentLearners/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            StudentLearner studentLearner = db.StudentLearners.Find(id);
            if (studentLearner == null)
            {
                return HttpNotFound();
            }
            return View(studentLearner);
        }

        // POST: StudentLearners/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "StudentID,FirstName,LastName,Gender,CurrentYear,Street,City,State,Zip,Email,Phone,Country,ProgramID,TrackID")] StudentLearner studentLearner)
        {
            if (ModelState.IsValid)
            {
                db.Entry(studentLearner).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(studentLearner);
        }

        // GET: StudentLearners/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            StudentLearner studentLearner = db.StudentLearners.Find(id);
            if (studentLearner == null)
            {
                return HttpNotFound();
            }
            return View(studentLearner);
        }

        // POST: StudentLearners/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            StudentLearner studentLearner = db.StudentLearners.Find(id);
            db.StudentLearners.Remove(studentLearner);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
