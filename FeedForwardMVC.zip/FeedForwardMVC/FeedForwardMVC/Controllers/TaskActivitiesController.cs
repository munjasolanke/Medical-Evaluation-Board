﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using FeedForwardMVC.Models;

namespace FeedForwardMVC.Controllers
{
    public class TaskActivitiesController : Controller
    {
        private FeedForward1Entities db = new FeedForward1Entities();

        // GET: TaskActivities
        public ActionResult Index()
        {
            var taskActivities = db.TaskActivities.Include(t => t.Competency).Include(t => t.StudentLearner);
            return View(taskActivities.ToList());
        }

        // GET: TaskActivities/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TaskActivity taskActivity = db.TaskActivities.Find(id);
            if (taskActivity == null)
            {
                return HttpNotFound();
            }
            return View(taskActivity);
        }

        // GET: TaskActivities/Create
        public ActionResult Create()
        {
            ViewBag.CompetencyID = new SelectList(db.Competencies, "CompID", "CompTitle");
            ViewBag.StudentID = new SelectList(db.StudentLearners, "StudentID", "FirstName");
            return View();
        }

        // POST: TaskActivities/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "TaskID,DateTimeRequested,DateTimeFeedback,Result,TaskComment,CommentType,CompetencyID,StudentID,EvaluatorID")] TaskActivity taskActivity)
        {
            if (ModelState.IsValid)
            {
                db.TaskActivities.Add(taskActivity);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.CompetencyID = new SelectList(db.Competencies, "CompID", "CompTitle", taskActivity.CompetencyID);
            ViewBag.StudentID = new SelectList(db.StudentLearners, "StudentID", "FirstName", taskActivity.StudentID);
            return View(taskActivity);
        }

        // GET: TaskActivities/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TaskActivity taskActivity = db.TaskActivities.Find(id);
            if (taskActivity == null)
            {
                return HttpNotFound();
            }
            ViewBag.CompetencyID = new SelectList(db.Competencies, "CompID", "CompTitle", taskActivity.CompetencyID);
            ViewBag.StudentID = new SelectList(db.StudentLearners, "StudentID", "FirstName", taskActivity.StudentID);
            return View(taskActivity);
        }

        // POST: TaskActivities/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "TaskID,DateTimeRequested,DateTimeFeedback,Result,TaskComment,CommentType,CompetencyID,StudentID,EvaluatorID")] TaskActivity taskActivity)
        {
            if (ModelState.IsValid)
            {
                db.Entry(taskActivity).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CompetencyID = new SelectList(db.Competencies, "CompID", "CompTitle", taskActivity.CompetencyID);
            ViewBag.StudentID = new SelectList(db.StudentLearners, "StudentID", "FirstName", taskActivity.StudentID);
            return View(taskActivity);
        }

        // GET: TaskActivities/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TaskActivity taskActivity = db.TaskActivities.Find(id);
            if (taskActivity == null)
            {
                return HttpNotFound();
            }
            return View(taskActivity);
        }

        // POST: TaskActivities/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            TaskActivity taskActivity = db.TaskActivities.Find(id);
            db.TaskActivities.Remove(taskActivity);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
